"""
Topsis-Sameer-102316089

A Python package that implements the TOPSIS (Technique for Order of Preference
by Similarity to Ideal Solution) method for multi-criteria decision making.
"""

__version__ = "1.0.2"
__author__ = "Sameer"
