"""Allow running with: python -m topsis_sameer_102316089"""
from topsis_sameer_102316089.topsis import main

main()
